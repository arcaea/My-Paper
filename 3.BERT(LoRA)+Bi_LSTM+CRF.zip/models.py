# -*- coding: utf-8 -*-
'''
@Author: Xavier WU
@Date: 2021-11-30
@LastEditTime: 2022-1-6
@Description: This file is for building model. 
@All Right Reserve
'''

import torch
import torch.nn as nn
from transformers import AutoModel, BertConfig
from torchcrf import CRF
from peft import TaskType, LoraConfig, get_peft_model


class Bert_LoRA_BiLSTM_CRF(nn.Module):
    def __init__(self, tag_to_ix, num_layers_to_finetune, r, lora_alpha, lora_dropout, embedding_dim=768, hidden_dim=256):
        super(Bert_LoRA_BiLSTM_CRF, self).__init__()
        self.tag_to_ix = tag_to_ix
        self.tagset_size = len(tag_to_ix)
        self.num_layers_to_finetune = num_layers_to_finetune
        self.r = r
        self.lora_alpha = lora_alpha
        self.lora_dropout = lora_dropout
        self.hidden_dim = hidden_dim
        self.embedding_dim = embedding_dim


        # 创建并加载具有隐藏状态的BERT模型。

        self.bert = AutoModel.from_pretrained('bert-base-chinese')

        # 微调指定的层。
        self.fine_tune_layers()

        self.lora_config = LoraConfig(
            r = self.r,
            lora_alpha = self.lora_alpha,
            lora_dropout = self.lora_dropout,
            task_type = None, # IndexError: The shape of the mask [64] at index 0 does not match the shape of the indexed tensor [24] at index 0
            # task_type = TaskType.SEQ_CLS, # TypeError: forward() got an unexpected keyword argument 'labels'
            # task_type = TaskType.CAUSAL_LM, # TypeError: forward() got an unexpected keyword argument 'labels'
            # task_type = TaskType.SEQ_2_SEQ_LM, # TypeError: forward() got an unexpected keyword argument 'decoder_input_ids'
            # task_type = TaskType.TOKEN_CLS, # TypeError: forward() got an unexpected keyword argument 'labels'
            inference_mode = True,
        )

        self.bert = get_peft_model(self.bert, self.lora_config)

        self.lstm = nn.LSTM(input_size=embedding_dim, hidden_size=hidden_dim // 2,
                            num_layers=2, bidirectional=True, batch_first=True)
        self.dropout = nn.Dropout(p=0.1)
        self.linear = nn.Linear(hidden_dim, self.tagset_size)
        self.crf = CRF(self.tagset_size, batch_first=True)

    def fine_tune_layers(self):
        # 冻结所有层。
        for param in self.bert.parameters():
            param.requires_grad = False

        # # 解冻指定的层。
        for i in range(12 - self.num_layers_to_finetune, 12):
            for param in self.bert.encoder.layer[i].parameters():
                param.requires_grad = True
    
    def _get_features(self, sentence,mask):
        # with torch.no_grad():
        #   embeds = self.bert(sentence)['last_hidden_state']
        # enc, _ = self.lstm(embeds)
        # enc = self.dropout(enc)
        # feats = self.linear(enc)
        with torch.no_grad():
           embeds = self.bert(sentence, attention_mask=mask)['last_hidden_state']
        enc, _ = self.lstm(embeds)
        enc = self.dropout(enc)
        feats = self.linear(enc)
        return feats

    def forward(self, sentence, tags, mask, is_test=False):
        emissions = self._get_features(sentence,mask)
        if not is_test: # Training，return loss
            loss=-self.crf.forward(emissions, tags, mask, reduction='mean')
            return loss
        else: # Testing，return decoding
            decode=self.crf.decode(emissions, mask)
            return decode
        
"""
#################################
#   ClinicalDistilBERT_BiLSTM_CRF
#################################

class ClinicalDistilBERT_BiLSTM_CRF(nn.Module):

    def __init__(self, tag_to_ix, embedding_dim=768, hidden_dim=256):
        super(ClinicalDistilBERT_BiLSTM_CRF, self).__init__()
        self.tag_to_ix = tag_to_ix
        self.tagset_size = len(tag_to_ix)
        self.hidden_dim = hidden_dim
        self.embedding_dim = embedding_dim

        # Build the DistilBERT model, including outputting all hidden states
        config = AutoTokenizer.from_pretrained("medicalai/ClinicalBERT", output_hidden_states=True)
        self.bert = AutoModel.from_pretrained("medicalai/ClinicalBERT", config=config)


        self.lstm = nn.LSTM(input_size=embedding_dim, hidden_size=hidden_dim//2,
                            num_layers=2, bidirectional=True, batch_first=True)
        self.dropout = nn.Dropout(p=0.1)
        self.linear = nn.Linear(hidden_dim, self.tagset_size)
        self.crf = CRF(self.tagset_size, batch_first=True)

    def _get_features(self, sentence):
        with torch.no_grad():
            embeds = self.bert(sentence)['last_hidden_state']
        enc, _ = self.lstm(embeds)
        enc = self.dropout(enc)
        feats = self.linear(enc)
        return feats

    def forward(self, sentence, tags, mask, is_test=False):
        emissions = self._get_features(sentence)
        if not is_test:  # Training, return loss
            loss = -self.crf.forward(emissions, tags, mask, reduction='mean')
            return loss
        else:  # Testing, return decoding
            decode = self.crf.decode(emissions, mask)
            return decode


###################
#   Bert_BiLSTM_CRF
###################

import torch
import torch.nn as nn
from transformers import BertModel
from torchcrf import CRF

class Bert_BiLSTM_CRF(nn.Module):

    def __init__(self, tag_to_ix, embedding_dim=768, hidden_dim=256):
        super(Bert_BiLSTM_CRF, self).__init__()
        self.tag_to_ix = tag_to_ix
        self.tagset_size = len(tag_to_ix)
        self.hidden_dim = hidden_dim
        self.embedding_dim = embedding_dim

        # self.bert = BertModel.from_pretrained('bert-base-chinese')
        self.bert = BertModel.from_pretrained('bert-base-chinese',return_dict=False)
        self.lstm = nn.LSTM(input_size=embedding_dim, hidden_size=hidden_dim//2,
                            num_layers=2, bidirectional=True, batch_first=True)
        self.dropout = nn.Dropout(p=0.1)
        self.linear = nn.Linear(hidden_dim, self.tagset_size)
        self.crf = CRF(self.tagset_size, batch_first=True)
    
    def _get_features(self, sentence):
        with torch.no_grad():
          embeds, _  = self.bert(sentence)
        enc, _ = self.lstm(embeds)
        enc = self.dropout(enc)
        feats = self.linear(enc)
        return feats

    def forward(self, sentence, tags, mask, is_test=False):
        emissions = self._get_features(sentence)
        if not is_test: # Training，return loss
            loss=-self.crf.forward(emissions, tags, mask, reduction='mean')
            return loss
        else: # Testing，return decoding
            decode=self.crf.decode(emissions, mask)
            return decode

"""